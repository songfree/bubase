// changedbpwd.cpp : Defines the entry point for the console application.
//
#include "public.h"
#include "TradeInfoBus.h"
#include "BF_LogClient.h"
#include "BF_Timer.h"

#ifdef _WINDOWS
#ifdef _DEBUG

#pragma comment(lib, "bf_kerneld.lib") 
#pragma comment(lib, "bf_tibd.lib") 
#pragma message("Automatically linking with   bf_kerneld.lib bf_tibd.lib")
#else
#pragma comment(lib, "bf_kernel.lib") 
#pragma comment(lib, "bf_tib.lib") 
#pragma message("Automatically linking with   bf_kernel.lib bf_tib.lib")
#endif
#endif

int g_datanum;

static int OnTimer(unsigned int eventid,void *p)
{
	printf("���յ�����������%d\n",g_datanum);
	return 0;
}
int main(int argc, char* argv[])
{

	char errmsg[256];
	CTradeInfoBus   tib;
	CBF_Timer m_timer;
	CBF_LogClient log;
	log.SetMaxLogSize(1024*1024*5);
	log.SetLogPara(LOG_DEBUG+1,"","testtib.log");
	
	log.StartLog();

	if (!tib.Init(&log,"bftib.xml"))
	{
		printf("init����\n");
		log.LogMp(LOG_ERROR,__FILE__,__LINE__,"Init ����");
		log.StopLog();
		return -1;
	}
	if (!tib.StartRecv())
	{
		printf("���������߳� ����\n");
		log.LogMp(LOG_ERROR,__FILE__,__LINE__,"���������߳� ����");
		log.StopLog();
		return -1;
	}
	m_timer.Init(1000);
	m_timer.SetTimer(0,5000,&OnTimer,NULL);
	m_timer.Start();
	TIBCOMMSTRU data;
	g_datanum = 0;
	while (true)
	{
		if (tib.GetData(data)<0)
		{
			continue;
		}
		g_datanum++;

	}

	
	return 0;
}
