cd dreb1
rm -rf log data
cd ../dreb2
rm -rf log data
cd ../dreb3
rm -rf log data
cd ../dreb4
rm -rf log data
cd ../bpc1
rm -rf log data
cd ../bpc2
rm -rf log data
cd ../monitor
rm -rf log data
cd ../cgate1
rm -rf log data
cd ../cgate2
rm -rf log data
cd ..

