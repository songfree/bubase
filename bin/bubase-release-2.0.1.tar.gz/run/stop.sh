cd dreb1
bfdreb stop
cd ../dreb2
bfdreb stop
cd ../dreb3
bfdreb stop
cd ../dreb4
bfdreb stop
cd ../bpc1
bfsap stop
bfspu stop
cd ../bpc2
bfsap stop
bfspu stop
cd ../monitor
bfsap stop
bfspu stop
cd ../cgate1
bfcgate stop
cd ../cgate2
bfcgate stop
cd ../bfarb
bfarb stop


