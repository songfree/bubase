cd dreb1
bfdreb
cd ../dreb2
bfdreb
cd ../dreb3
bfdreb 
cd ../dreb4
bfdreb 
cd ../bpc1
bfsap
cd ../bpc2
bfsap
cd ../monitor
bfsap
cd ../cgate1
bfcgate
cd ../cgate2
bfcgate
cd ../arb
bfarb

