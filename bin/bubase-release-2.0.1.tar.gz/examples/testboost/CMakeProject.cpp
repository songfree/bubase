﻿#include <iostream>
#include <boost/multi_index_container.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/multi_index/identity.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/composite_key.hpp>


#include "typedefine.h"
#include "MdbBase.h"
#include "BF_Mutex.h"
#include "BF_Date_Time.h"

#ifdef WIN32
#ifdef _DEBUG
#pragma comment(lib, "bf_kerneld.lib") 
#pragma message("Automatically linking with  bf_kerneld.lib")
#else
#pragma comment(lib, "bf_kernel.lib") 
#pragma message("Automatically linking with  bf_kernel.lib")
#endif
#endif

using namespace boost::multi_index;

typedef char type_term_id[33];
typedef char type_hj_code[33];
//交易订单表 
typedef  struct _JyOrderStruct {
    char trday[8 + 1] = { 0 };
    char term_id[32 + 1] = { 0 };
    int32_t oper_id = 0;
    UINT64_ account_id = 0;
    UINT64_ portfolio_id = 0;
    char tract_code[32 + 1] = { 0 };
    UINT64_ term_order_id = 0;
    UINT64_ p_order_id = 0;
    UINT64_ sys_order_id = 0;
    double margin_rate = 0.00;
    char broker_send_id[32 + 1] = { 0 };
    char broker_order_id[32 + 1] = { 0 };
    UINT64_ order_time = 0;
    char hj_code[32 + 1] = { 0 };
    int32_t market_id = 0;
    char market_code[32 + 1] = { 0 };
    char cname[32 + 1] = { 0 };
    int32_t command_id = 0;
    int32_t execution = 0;
    int32_t currency_id = 0;
    int64_t order_price = 0;
    int32_t order_vol = 0;
    int32_t cancel_vol = 0;
    int32_t match_vol = 0;
    UINT64_ match_amt = 0;
    UINT64_ update_time = 0;
    UINT64_ cancel_time = 0;
    char approver[32 + 1] = { 0 };
    char order_stat[4 + 1] = { 0 };
    int32_t add_order_type = 0;
    char add_order_feeset[16 + 1] = { 0 };
    int32_t source_type = 0;
    int32_t ret_code = 0;
    char msg[1000 + 1] = { 0 };
}S_MDB_JyOrder;
//交易订单表的账户+策略ID+hjcode的索引
class Index_JyOrder_AccPortfCode : public CIndex_Field_Base
{
public:
    UINT64_ account_id = 0;//资金账号
    UINT64_ portfolio_id = 0;//策略ID
    char    hj_code[33] = { 0 };//代码
    virtual bool operator<(const Index_JyOrder_AccPortfCode& field) const
    {
        int ret = account_id - field.account_id;
        if (ret < 0)
        {
            return true;
        }
        else if (ret == 0)
        {
            int ret2 = portfolio_id - field.portfolio_id;
            if (ret2 < 0)
            {
                return true;
            }
            else if (ret2 == 0)
            {
                ret = strcmp(hj_code, field.hj_code);
                if (ret < 0)
                {
                    return true;
                }
            }
            return false;
        }
        return false;
    }
};
//订单内存表
class CTbl_JyOrder {
protected:

    CMemTableNew<S_MDB_JyOrder> m_table;
    CPkeyUint64<1>   m_key; //系统报单号
    CIndexUint64<2>  m_index_term_id;//终端id 终端报单号的索引
    CIndexUint64<1>  m_index_account;//account_id的索引
    CIndexUint64<2>  m_index_account_portfolio_id;//account_id portfolio_id的索引
    CIndexField<Index_JyOrder_AccPortfCode> m_index_accportfcode;//账户+策略+HJCODE的索引
    CBF_Mutex m_mutex;//互斥锁
    CInt  m_rid_update;//存放更新的Rowrid
public:
    CTbl_JyOrder() {

    }
    virtual ~CTbl_JyOrder() {

    }
    void Clear() {
        m_key.Clear();
        m_index_term_id.Clear();
        m_index_accportfcode.Clear();
        m_index_account.Clear();
        m_index_account_portfolio_id.Clear();
        m_table.Clear();
    }
    //写入数据
    int Insert(S_MDB_JyOrder info, bool isupdate = false) {
        CBF_PMutex pp(&m_mutex);
        if (m_key.Find(info.sys_order_id)) {
            return -1;
        }
        int rid = m_table.Add(info);
        m_key.Add(rid, (UINT64_)m_table.m_table[rid].sys_order_id);
        m_index_term_id.Add(rid, atoi(m_table.m_table[rid].term_id), (UINT64_)m_table.m_table[rid].term_order_id);
        m_index_account.Add(rid, (UINT64_)m_table.m_table[rid].account_id);
        m_index_account_portfolio_id.Add(rid, (UINT64_)m_table.m_table[rid].account_id, m_table.m_table[rid].portfolio_id);
        Index_JyOrder_AccPortfCode bb;
        strncpy(bb.hj_code, info.hj_code, sizeof(bb.hj_code) - 1);
        bb.account_id = info.account_id;
        bb.portfolio_id = info.portfolio_id;
        bb.m_nRowId = rid;
        m_index_accportfcode.Add(bb);
        if (isupdate)
        {
            m_rid_update.Add(rid);
        }
        return rid;
    }
    int SetUpdate(S_MDB_JyOrder info) {
        CBF_PMutex pp(&m_mutex);
        int rid;
        if (m_key.Select(rid, info.sys_order_id)) {
            m_rid_update.Add(rid);
            return rid;
        }
        return -1;
    }
    int SetUpdate(int rid) {
        CBF_PMutex pp(&m_mutex);
        if (At(rid) == NULL)
        {
            return -1;
        }
        m_rid_update.Add(rid);
        return 0;
    }
    int Update(S_MDB_JyOrder info, bool isupdate = false) {
        CBF_PMutex pp(&m_mutex);
        int rid;
        if (m_key.Select(rid, info.sys_order_id)) {
            m_table.m_table[rid] = info;
            //如果索引有更新，则要重建索引
            if (isupdate)
            {
                m_rid_update.Add(rid);
            }
            return rid;
        }
        rid = m_table.Add(info);
        m_key.Add(rid, (UINT64_)m_table.m_table[rid].sys_order_id);
        m_index_term_id.Add(rid, atoi(m_table.m_table[rid].term_id), (UINT64_)m_table.m_table[rid].term_order_id);
        m_index_account.Add(rid, (UINT64_)m_table.m_table[rid].account_id);
        m_index_account_portfolio_id.Add(rid, (UINT64_)m_table.m_table[rid].account_id, m_table.m_table[rid].portfolio_id);
        Index_JyOrder_AccPortfCode bb;
        strncpy(bb.hj_code, info.hj_code, sizeof(bb.hj_code) - 1);
        bb.account_id = info.account_id;
        bb.portfolio_id = info.portfolio_id;
        bb.m_nRowId = rid;
        m_index_accportfcode.Add(bb);
        if (isupdate)
        {
            m_rid_update.Add(rid);
        }
        return rid;
    }
    void GetUpdateList(std::vector<S_MDB_JyOrder*>& reslist, bool dellist = true)
    {
        CBF_PMutex pp(&m_mutex);
        int rid;
        bool bret = m_rid_update.First(rid);
        while (bret)
        {
            reslist.push_back(&(m_table.m_table[rid]));
            bret = m_rid_update.Next(rid);
        }
        if (dellist)
        {
            m_rid_update.Clear();
        }
        return;
    }
    //删除资金账号的持仓
    bool Delete(UINT64_ account_id)
    {
        CBF_PMutex pp(&m_mutex);
        CInt iset;
        bool bret = m_index_account.Select(iset, account_id);
        if (!bret)
        {
            return false;
        }
        m_index_account.Delete(iset);
        m_index_term_id.Delete(iset);
        m_index_accportfcode.Delete(iset);
        m_index_account_portfolio_id.Delete(iset);
        m_key.Delete(iset);
        int rid;
        bret = iset.First(rid);
        while (bret)
        {
            m_rid_update.Delete(rid);
            m_table.Delete(rid);
            bret = iset.Next(rid);
        }
        return true;
    }
    //根据报单号取出数据
    S_MDB_JyOrder* Select(UINT64_ sys_order_id) {
        CBF_PMutex pp(&m_mutex);
        int rid;
        if (!m_key.Select(rid, sys_order_id)) {
            return NULL;
        }
        return &(m_table.m_table[rid]);
    }
    //根据主键获取rowid
    int GetRowId(UINT64_ sys_order_id)
    {
        int rid;
        CBF_PMutex pp(&m_mutex);
        if (!m_key.Select(rid, sys_order_id))
        {
            return -1;
        }
        return rid;
    }
    //根据账号、策略、代码取出所有的报单
    bool Select(UINT64_ account_id, UINT64_ portfolio_id, char* hj_code, std::vector<S_MDB_JyOrder*>& reslist)
    {
        CBF_PMutex pp(&m_mutex);
        Index_JyOrder_AccPortfCode bb;
        strncpy(bb.hj_code, hj_code, sizeof(bb.hj_code) - 1);
        bb.account_id = account_id;
        bb.portfolio_id = portfolio_id;
        bool bret = m_index_accportfcode.Find(bb);
        if (!bret)
        {
            return false;
        }
        while (bret)
        {
            reslist.push_back(&(m_table.m_table[bb.m_nRowId]));
            bret = m_index_accportfcode.Next(bb);
        }
        return true;
    }
    //根据账号、策略、代码取出所有的报单
    bool Select(UINT64_ account_id, UINT64_ portfolio_id, std::vector<S_MDB_JyOrder*>& reslist)
    {
        CBF_PMutex pp(&m_mutex);
        int rid;
        bool bret = m_index_account_portfolio_id.Find(rid, account_id, portfolio_id);
        if (!bret)
        {
            return false;
        }
        while (bret)
        {
            reslist.push_back(&(m_table.m_table[rid]));
            bret = m_index_account_portfolio_id.Next(rid);
        }
        return true;
    }
    //根据账号取出所有的报单
    bool SelectByAccount(UINT64_ account_id, std::vector<S_MDB_JyOrder*>& reslist)
    {
        CBF_PMutex pp(&m_mutex);
        int rid;
        bool bret = m_index_account.Find(rid, account_id);
        if (!bret)
        {
            return false;
        }
        while (bret)
        {
            reslist.push_back(&(m_table.m_table[rid]));
            bret = m_index_account.Next(rid);
        }
        return true;
    }
    //取出所有的报单
    bool Select(std::vector<S_MDB_JyOrder*>& reslist)
    {
        CBF_PMutex pp(&m_mutex);
        int rid;
        bool bret = m_key.First(rid);
        if (!bret)
        {
            return false;
        }
        while (bret)
        {
            reslist.push_back(&(m_table.m_table[rid]));
            bret = m_key.Next(rid);
        }
        return true;
    }
    //根据终端报单号取出所有的报单
    bool SelectByTerm(UINT64_ term_id, UINT64_ term_order_id, std::vector<S_MDB_JyOrder*>& reslist)
    {
        CBF_PMutex pp(&m_mutex);
        int rid;
        bool bret = m_index_term_id.Find(rid, term_id, term_order_id);
        if (!bret)
        {
            return false;
        }
        while (bret)
        {
            reslist.push_back(&(m_table.m_table[rid]));
            bret = m_index_term_id.Next(rid);
        }
        return true;
    }
    //根据rowid取到记录
    S_MDB_JyOrder* At(int rowid) {
        if (rowid < 0 || rowid > m_table.AllSize() - 1) {
            return NULL;
        }
        return &(m_table.m_table[rowid]);
    }

    int Size() {
        return m_key.Size();
    }
    std::string getRedisKey(S_MDB_JyOrder info)
    {
        std::string s;
        s.append("JyOrder").append("--");
        s.append(std::to_string(info.sys_order_id)).append(":");
        return std::move(s);
    }
};

struct employee
{
    int         id;
    std::string name;
    std::string code;
    bool operator<(const employee& e)const { return id < e.id; }

    friend std::ostream& operator<<(std::ostream& os, const employee& other)
    {
        std::cout << other.id << " " << other.name <<" " <<other.code << std::endl;
        return os;
    }
};

// define a multiply indexed set with indices by id and name
typedef multi_index_container<
    employee,
    indexed_by<
    // sort by employee::operator<
    //ordered_unique<identity<BOOST_MULTI_INDEX_MEMBER (employee,int, &employee::id)> >,
    //ordered_unique<identity<employee> >,
        ordered_unique<BOOST_MULTI_INDEX_MEMBER(employee, int, id) >,
    // sort by less<string> on name
        ordered_non_unique<
            composite_key<employee,
                BOOST_MULTI_INDEX_MEMBER(employee, std::string, name), 
                member<employee, std::string, &employee::code> 
            >
        
        >,
        ordered_non_unique<
            composite_key<employee,
                BOOST_MULTI_INDEX_MEMBER(employee, std::string, name) 
            >
        >
    >
> employee_set;

void print_out_by_name(const employee_set& es)
{
    // get a view to index #1 (name)
    const employee_set::nth_index<1>::type& name_index = es.get<1>();
    // use name_index as a regular std::set
    std::copy(
        name_index.begin(), name_index.end(),
        std::ostream_iterator<employee>(std::cout));
}

template<class T>
struct my_less
{
    bool operator()(const char* p1, const char* p2) const
    {
        return strcmp(p1, p2) < 0;
    }
    bool operator()(const std::string& p1, const std::string& p2) const
    {
        return p1 < p2;
    }
    bool operator()(const std::string& p1, const char* p2) const
    {
        return strcmp(p1.c_str(), p2) < 0;
    }
    bool operator()(const char* p1, const std::string& p2) const
    {
        return strcmp(p1, p2.c_str()) < 0;
    }
    //对于数值类型的数据，系统中除了字符串数组，就是数值类型的
    //template<class T>
    bool operator()(T _Left, T _Right) const
    {
        return std::less<T>()(_Left, _Right);
    }
};
typedef multi_index_container <
    S_MDB_JyOrder,
    indexed_by<
        ordered_unique<BOOST_MULTI_INDEX_MEMBER(S_MDB_JyOrder, UINT64_, sys_order_id) >,
        ordered_non_unique<
            composite_key<S_MDB_JyOrder,
                BOOST_MULTI_INDEX_MEMBER(S_MDB_JyOrder, type_term_id, term_id),
                member<S_MDB_JyOrder, UINT64_, &S_MDB_JyOrder::term_order_id>
            >
            , composite_key_compare<
                my_less<type_term_id>,
                my_less<UINT64_>
            >
        >,
        ordered_non_unique<
            composite_key<S_MDB_JyOrder,
                BOOST_MULTI_INDEX_MEMBER(S_MDB_JyOrder, UINT64_, account_id)
            >
        >,
        ordered_non_unique<
            composite_key<S_MDB_JyOrder,
                BOOST_MULTI_INDEX_MEMBER(S_MDB_JyOrder, UINT64_, account_id),
                BOOST_MULTI_INDEX_MEMBER(S_MDB_JyOrder, UINT64_, portfolio_id)
            >
        > ,
        ordered_non_unique<
            composite_key<S_MDB_JyOrder,
                BOOST_MULTI_INDEX_MEMBER(S_MDB_JyOrder, UINT64_, account_id),
                BOOST_MULTI_INDEX_MEMBER(S_MDB_JyOrder, UINT64_, portfolio_id),
                BOOST_MULTI_INDEX_MEMBER(S_MDB_JyOrder, type_hj_code, hj_code)
            >
           , composite_key_compare<
                my_less<UINT64_>,
                my_less<UINT64_>,
                my_less<type_hj_code>
            >
       >
    >
> JyOrder_boost;

//订单内存表
class CTbl_JyOrder_boost {
protected:

    JyOrder_boost m_table;
    
    CBF_Mutex m_mutex;//互斥锁
    CInt  m_rid_update;//存放更新的Rowrid
public:
    CTbl_JyOrder_boost() {

    }
    virtual ~CTbl_JyOrder_boost() {

    }
    void Clear() {

    }
    //写入数据
    int Insert(S_MDB_JyOrder info, bool isupdate = false) {
        CBF_PMutex pp(&m_mutex);
        m_table.insert(info);
        return 0;
    }
    int SetUpdate(S_MDB_JyOrder info) {
        CBF_PMutex pp(&m_mutex);
        return -1;
    }
    int SetUpdate(int rid) {
        return 0;
    }
    int Update(S_MDB_JyOrder info, bool isupdate = false) {
        CBF_PMutex pp(&m_mutex);
        int rid;
        const JyOrder_boost::nth_index<0>::type& order_index = m_table.get<0>();
        //m_table.modify(info,0);
        
        return rid;
    }
    void GetUpdateList(std::vector<S_MDB_JyOrder*>& reslist, bool dellist = true)
    {
        CBF_PMutex pp(&m_mutex);

        return;
    }
    //删除资金账号的持仓
    bool Delete(UINT64_ account_id)
    {
        CBF_PMutex pp(&m_mutex);
        const JyOrder_boost::nth_index<0>::type& key = m_table.get<0>();
        const JyOrder_boost::nth_index<2>::type& jyorder_index = m_table.get<2>();
        JyOrder_boost::nth_index<2>::type::iterator it = jyorder_index.find(account_id);
        auto end = jyorder_index.upper_bound(account_id);
        while (it != end)
        {
 //           key.erase(it->sys_order_id);
            it++;
        }
        return true;
    }
    //根据报单号取出数据
    const S_MDB_JyOrder* Select(UINT64_ sys_order_id) {
        CBF_PMutex pp(&m_mutex);
        const JyOrder_boost::nth_index<0>::type& jyorder_index = m_table.get<0>();
        JyOrder_boost::nth_index<0>::type::iterator it = jyorder_index.find(sys_order_id);
        
        if (it != jyorder_index.end())
        {
           return &(*it); 
        }
        return NULL;
    }
   
    //根据账号、策略、代码取出所有的报单
    bool Select(UINT64_ account_id, UINT64_ portfolio_id,const type_hj_code hj_code, std::vector<const S_MDB_JyOrder*>& reslist)
    {
        CBF_PMutex pp(&m_mutex);
        const JyOrder_boost::nth_index<4>::type& jyorder_index = m_table.get<4>();
        JyOrder_boost::nth_index<4>::type::iterator it = jyorder_index.find(boost::make_tuple(account_id, portfolio_id, hj_code));
        auto end = jyorder_index.upper_bound(boost::make_tuple(account_id, portfolio_id, hj_code));
        while (it != end)
        {
            reslist.push_back(&(*it));
            it++;
        }
        return true;
    }
    //根据账号、策略、代码取出所有的报单
    bool Select(UINT64_ account_id, UINT64_ portfolio_id, std::vector<const S_MDB_JyOrder*>& reslist)
    {
        CBF_PMutex pp(&m_mutex);
        const JyOrder_boost::nth_index<3>::type& jyorder_index = m_table.get<3>();
        JyOrder_boost::nth_index<3>::type::iterator it = jyorder_index.find(std::make_tuple(account_id, portfolio_id));
        auto end = jyorder_index.upper_bound(std::make_tuple(account_id, portfolio_id));
        while (it != end)
        {
            reslist.push_back(&(*it));
            it++;
        }
        return true;
    }
    //根据账号取出所有的报单
    bool SelectByAccount(UINT64_ account_id, std::vector<const S_MDB_JyOrder*>& reslist)
    {
        CBF_PMutex pp(&m_mutex);
        const JyOrder_boost::nth_index<2>::type& jyorder_index = m_table.get<2>();
        JyOrder_boost::nth_index<2>::type::iterator it = jyorder_index.find(account_id);
        auto end = jyorder_index.upper_bound(account_id);
        while (it != end)
        {
            reslist.push_back(&(*it));
            it++;
        }
        return true;
    }
    //取出所有的报单
    bool Select(std::vector<S_MDB_JyOrder*>& reslist)
    {
        
        return true;
    }
    //根据终端报单号取出所有的报单
    bool SelectByTerm(char* term_id, UINT64_ term_order_id, std::vector<const S_MDB_JyOrder*>& reslist)
    {
        CBF_PMutex pp(&m_mutex);
        const JyOrder_boost::nth_index<1>::type& jyorder_index = m_table.get<1>();
        JyOrder_boost::nth_index<1>::type::iterator it = jyorder_index.find(std::make_tuple(term_id, term_order_id));
        auto end = jyorder_index.upper_bound(std::make_tuple(term_id, term_order_id));
        while (it != end)
        {
            reslist.push_back(&(*it));
            it++;
        }
        return true;
    }
    //根据rowid取到记录
    S_MDB_JyOrder* At(int rowid) {

    }

    int Size() {

    }

};
void main()
{
    //employee_set employs;
    //employee aa;
    //aa.id = 8;
    //aa.name = "yangdian";
    //aa.code = "1122";
    //employs.insert(aa);
    //aa.id = 3;
    //aa.name = "aaa111111";
    //aa.code = "2233";
    //employs.insert(aa);
    //aa.id = 4;
    //aa.name = "aaa111111";
    //aa.code = "112233";
    //employs.insert(aa);

    //const employee_set::nth_index<2>::type& name_index = employs.get<2>();
    ////auto it = name_index.find("aaa111111");
    //employee_set::nth_index<2>::type::iterator it= name_index.find("aaa111111");
    //auto end = name_index.upper_bound("aaa111111");//第一个大于此值的位置，以后可以Next使用
    //while (it != end)
    //{
    //    std::cout << it->id << " " << it->name << " " << it->code << std::endl;
    //    it++;
    //}
    //int_out_by_name(employs);

    // 100万次测试
    int testNum = 1000000;
    std::vector<S_MDB_JyOrder> vecPlayer;
    S_MDB_JyOrder jy_order;
    strcpy(jy_order.term_id,"0020");
    strcpy(jy_order.hj_code,"600585.sh");
    // 初始化
    for (int i = 0; i < testNum; i++)
    {
        jy_order.sys_order_id = i;
        jy_order.account_id = i;
        jy_order.portfolio_id = i;
        vecPlayer.push_back(jy_order);
    }
    // 随机打乱
    std::random_shuffle(vecPlayer.begin(), vecPlayer.end());
    CTbl_JyOrder_boost jy_boost;
    CTbl_JyOrder  jy;
    UINT64_ tms= CBF_Date_Time::GetTickCount(); 
    for (std::vector<S_MDB_JyOrder>::iterator it = vecPlayer.begin(); it != vecPlayer.end(); it++)
    {
        jy_boost.Insert(*it);
    }
    UINT64_ tms_end = CBF_Date_Time::GetTickCount();
    std::cout << " boost multi_index insert " << testNum << " 次耗时" << tms_end-tms <<" 平均" <<(tms_end-tms)/testNum<< std::endl;

    tms = CBF_Date_Time::GetTickCount();
    for (std::vector<S_MDB_JyOrder>::iterator it = vecPlayer.begin(); it != vecPlayer.end(); it++)
    {
        jy.Insert(*it);
    }
    tms_end = CBF_Date_Time::GetTickCount();
    std::cout << " bubase mdbbase insert " << testNum << " 次耗时" << tms_end - tms << " 平均" << (tms_end - tms) / testNum << std::endl;
    std::vector<const S_MDB_JyOrder*>reslist;
    tms = CBF_Date_Time::GetTickCount();
    for (std::vector<S_MDB_JyOrder>::iterator it = vecPlayer.begin(); it != vecPlayer.end(); it++)
    {
        jy_boost.Select(it->account_id,it->portfolio_id,it->hj_code, reslist);
        reslist.clear();
    }
    tms_end = CBF_Date_Time::GetTickCount();
    std::cout << " boost multi_index select " << testNum << " 次耗时" << tms_end - tms << " 平均" << (tms_end - tms) / testNum << std::endl;

    std::vector<S_MDB_JyOrder*>reslist2;
    tms = CBF_Date_Time::GetTickCount();
    for (std::vector<S_MDB_JyOrder>::iterator it = vecPlayer.begin(); it != vecPlayer.end(); it++)
    {
        jy.Select(it->account_id, it->portfolio_id, it->hj_code, reslist2);
        reslist2.clear();
    }
    tms_end = CBF_Date_Time::GetTickCount();
    std::cout << " bubase mdbbase select " << testNum << " 次耗时" << tms_end - tms << " 平均" << (tms_end - tms) / testNum << std::endl;
    return ;
}