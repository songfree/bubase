// DrebMsgThread.h: interface for the CDrebMsgThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DREBMSGTHREAD_H__EA86CEFD_D89A_4E1C_BDA8_357EA26B0495__INCLUDED_)
#define AFX_DREBMSGTHREAD_H__EA86CEFD_D89A_4E1C_BDA8_357EA26B0495__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "DrebMsgProcBase.h"

class CDrebMsgThread : public CDrebMsgProcBase  
{
public:
	CDrebMsgThread();
	virtual ~CDrebMsgThread();

	

};

#endif // !defined(AFX_DREBMSGTHREAD_H__EA86CEFD_D89A_4E1C_BDA8_357EA26B0495__INCLUDED_)
