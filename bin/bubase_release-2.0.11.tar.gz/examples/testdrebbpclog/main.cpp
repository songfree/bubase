// changedbpwd.cpp : Defines the entry point for the console application.
//
#include "public.h"
#include "BF_CommDataLog.h"

#ifdef _WINDOWS
#ifdef _DEBUG
#pragma comment(lib, "bf_dbpubd.lib") 
#pragma comment(lib, "bf_kerneld.lib") 
#pragma message("Automatically linking with  bf_dbpubd.lib bf_kerneld.lib ")
#else
#pragma comment(lib, "bf_dbpub.lib") 
#pragma comment(lib, "bf_kernel.lib") 
#pragma message("Automatically linking with   bf_dbpub.lib bf_kernel.lib ")
#endif
#endif

int main(int argc, char* argv[])
{

	char errmsg[256];
	
	CBF_CommDataLog log;
	
	log.SetLogPara(1024*8,LOG_DEBUG,"","dreb.dat","bpc.dat");
	
	log.StartLog();
	COMMSTRU data;
	bzero(&data,sizeof(COMMSTRU));
	data.head.cCmd = CMD_DPCALL;
	data.head.d_Dinfo.d_nServiceNo = 99912;
	strcpy(data.buffer,"123456789011111111");
	data.head.nLen = strlen(data.buffer);
	int i;
	for (i=0; i< 100 ; i++)
	{
		data.head.s_Sinfo.s_nSerial = i;
		log.LogDreb(LOG_DEBUG,&data,false);
		SLEEP(100);

	}


	data.head.cCmd = CMD_DPCALL;
	data.head.d_Dinfo.d_nServiceNo = 99913;
	strcpy(data.buffer,"111111111111111111111111111123456789011111111");
	data.head.nLen = strlen(data.buffer);
	for (i=0; i< 100 ; i++)
	{
		data.head.s_Sinfo.s_nSerial = i;
		log.LogDreb(LOG_DEBUG,&data,true);
		SLEEP(100);
		
	}
	BPCCOMMSTRU bpcdata;
	bzero(&bpcdata,sizeof(BPCCOMMSTRU));
	bpcdata.sBpcHead.cMsgType = MSG_REQ;
	bpcdata.sBpcHead.nIndex = 1; 
	bpcdata.sDBHead.cCmd = CMD_DPCALL;
	bpcdata.sDBHead.d_Dinfo.d_nServiceNo = 99914;
	strcpy(bpcdata.sBuffer,"3333333333333333333333333333333333333111111111111111111111111111123456789011111111");
	bpcdata.sDBHead.nLen = strlen(bpcdata.sBuffer);
	for (i=0; i< 100 ; i++)
	{
		bpcdata.sDBHead.s_Sinfo.s_nSerial = i;
		log.LogBpc(LOG_DEBUG,&bpcdata,false);
		SLEEP(100);
		
	}
	bpcdata.sBpcHead.cMsgType = MSG_REQ;
	bpcdata.sBpcHead.nIndex = 1; 
	bpcdata.sDBHead.cCmd = CMD_DPCALL;
	bpcdata.sDBHead.d_Dinfo.d_nServiceNo = 99915;
	strcpy(bpcdata.sBuffer,"555555555555555555555555555553333333333333333333333333333333333333111111111111111111111111111123456789011111111");
	bpcdata.sDBHead.nLen = strlen(bpcdata.sBuffer);
	for (i=0; i< 100 ; i++)
	{
		bpcdata.sDBHead.s_Sinfo.s_nSerial = i;
		log.LogBpc(LOG_DEBUG,&bpcdata,true);
		SLEEP(100);
		
	}
	log.StopLog();
	return 0;
}
