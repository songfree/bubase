// MdbBase.h: interface for the CMdbBase class.
//
//////////////////////////////////////////////////////////////////////

/***********************************************************************************
  ������־��¼
  ������: ������
  �������� 2010-4-26 9:43:25
  �汾: V1.00 
  ˵��: ʹ��STL������һ���ڴ�����ģ���࣬�򵥵��ڴ�⣬û������
 ***********************************************************************************/


#if !defined(AFX_MDBBASE_H__B2EF1D82_10E5_4C0B_B6EF_A98703B25A7C__INCLUDED_)
#define AFX_MDBBASE_H__B2EF1D82_10E5_4C0B_B6EF_A98703B25A7C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "public.h"
#include "BF_Tools.h"
#include "typedefine.h"
#include <set>
#include <vector>
#include <stack>
#include <list>
#include <queue>
#include <stdarg.h>

#if defined(WIN32)
#include <io.h>
#else
#define O_BINARY 0
#endif

using namespace std;

#ifdef WIN32
#pragma warning(disable:4786) 
#endif


//���ظ�����������
template<typename Record,typename Compare>
class CUniqueIndexBase
{
public:
	typedef std::set<Record,Compare> SET_;
	typedef typename SET_::iterator LP_SET;
	SET_    m_index;//�������ݣ�Record�������ظ�
	LP_SET  m_current;//��ǰ����

public:
	CUniqueIndexBase()
	{
	}
	~CUniqueIndexBase()
	{
		Clear();
	}
	void Clear()
	{
		m_index.clear();
	}
	bool First(Record& rt)
	{
		m_current = m_index.begin();
		if(m_current == m_index.end())
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	bool Next(Record& rt)
	{
		m_current++;
		if(m_current == m_index.end())
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	bool End(Record& rt)
	{
		m_current = m_index.end();
		if(m_current == m_index.begin())
		{
			return false;
		}
		else
		{
			m_current--;
			rt = *m_current;
			return true;
		}
	}
	bool Last(Record& rt)
	{
		if(m_current == m_index.begin())
		{
			return false;
		}
		else
		{
			m_current--;
			rt = *m_current;
			return true;
		}
	}
	bool Find(Record& rt)
	{
		m_current = m_index.find(rt);
		if(m_current == m_index.end())
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	bool Add(Record& rt)
	{
// #ifdef _GCC
// 		Erase(rt);
// #endif
		pair<LP_SET,bool> r = m_index.insert(rt);
		return r.second;
// #ifndef _GCC
// 		if(!r.second) *r.first = rt;
// #endif
	}
	void Erase(Record& rt)
	{
		m_index.erase(rt);
	}
	int Size()
	{
		return m_index.size();
	}
};


//�ظ�����������
template<typename Record,typename Compare>
class CRepeatIndexBase
{
public:
	typedef std::multiset<Record,Compare> MULTISET_;
	typedef typename MULTISET_::iterator LP_MULTISET;
	MULTISET_    m_index;   //�������� Record�����ж��
	LP_MULTISET  m_current; 
	LP_MULTISET  m_end;
	LP_MULTISET  m_begin;
	bool         m_bDroped;

public:
	CRepeatIndexBase()
	{
		m_bDroped=false;
	}
	~CRepeatIndexBase()
	{
		Clear();
	}
	void Clear()
	{
		m_index.clear();
	}
	bool End(Record& rt)
	{
		m_begin = m_index.begin();
		m_current = m_index.end();
		if(m_current == m_end)
		{
			return false;
		}
		else 
		{
			m_current--;
			rt = *m_current;
			return true;
		}
	}
	bool Last(Record& rt)
	{
		if (!m_bDroped)
		{
			m_current--;
		}
		else
		{
			m_bDroped=false;
		}
		if(m_current == m_begin)
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	bool First(Record& rt)
	{
		m_current = m_index.begin();
		m_end=m_index.end();
		if(m_current == m_end)
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	bool Next(Record& rt)
	{
		if (!m_bDroped)
		{
			m_current++;
		}
		else
		{
			m_bDroped=false;
		}
		if(m_current == m_end)
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	//���ҵ�һ����λ�ú����һ�����ڴ�ֵ��λ�ã�NEXT��������֮��ȡ�ö����ֵͬ������
	bool Find(Record& rt)
	{
		m_bDroped=false;
		m_current = m_index.find(rt);
		m_end=m_index.upper_bound(rt);//��һ�����ڴ�ֵ��λ�ã��Ժ����Nextʹ��
		if(m_current == m_end)
		{
			return false;
		}
		else
		{
			if (m_current == m_index.end())
			{
				return false;
			}
			else
			{
				rt = *m_current;
				return true;
			}
		}
	}
	//���ҵ�һ����λ�ã�NEXT���Լ����ң�ֻҪ������
	bool FindFirst(Record& rt)
	{
		m_bDroped=false;
		m_current = m_index.find(rt);
		m_end= m_index.end();
		if(m_current == m_end)
		{
			return false;
		}
		else
		{
			if (m_current == m_index.end())
			{
				return false;
			}
			else
			{
				rt = *m_current;
				return true;
			}
		}
		
	}
	void Add(Record& rt)
	{
		m_index.insert(rt);
	}

	void EraseOne()
	{
		m_index.erase(m_current++);
		m_bDroped=true;
	}

	void Erase(Record& rt)
	{
		m_index.erase(rt);
	}
	int Size()
	{
		return m_index.size();
	}
};

//����ROWID����,���ظ�  Ҫ�����������ɾ����ʹ�ã����ֱ��ʹ�����ݣ���ֱ����vector����rowid
class CInt
{
public:
	std::set<int>             m_intdata;
	std::set<int>::iterator   m_current;
	std::set<int>::iterator   m_end;
	std::set<int>::iterator   m_begin;
public:
	CInt()
	{

	}
	~CInt()
	{
		Clear();
	}
	void Add(int id)
	{
		m_intdata.insert(id);
	}
	bool First(int &id)
	{
		m_current=m_intdata.begin();
		m_end=m_intdata.end();
		if (m_current == m_end)
		{
			return false;
		}
		else
		{
			id=*m_current;
			return true;
		}
	}
	bool Next(int &id)
	{
		m_current++;
		if (m_current == m_end)
		{
			return false;
		}
		else
		{
			id=*m_current;
			return true;
		}
	}
	bool End(int &id)
	{
		m_current=m_intdata.end();
		m_begin=m_intdata.begin();
		if (m_current == m_end)
		{
			return false;
		}
		else
		{
			m_current--;
			id=*m_current;
			return true;
		}
	}
	bool Last(int &id)
	{
		if (m_current == m_begin)
		{
			return false;
		}
		else
		{
			m_current--;
			id=*m_current;
			return true;
		}
	}
	bool Find(int id)
	{
		std::set<int>::iterator p;
		p = m_intdata.find(id);
		if (p == m_intdata.end())
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	void Clear()
	{
		m_intdata.clear();
	}
	int Size()
	{
		return m_intdata.size();
	}
};

//����ROWID����,���ظ� Ҫ�����������ɾ����ʹ�ã����ֱ��ʹ�����ݣ���ֱ����vector����rowid
class CUInt
{
public:
	std::set<unsigned int>             m_intdata;
	std::set<unsigned int>::iterator   m_current;
	std::set<unsigned int>::iterator   m_end;
	std::set<unsigned int>::iterator   m_begin;
public:
	CUInt()
	{
		
	}
	~CUInt()
	{
		Clear();
	}
	void Add(unsigned int id)
	{
		m_intdata.insert(id);
	}
	bool First(unsigned int &id)
	{
		m_current=m_intdata.begin();
		m_end=m_intdata.end();
		if (m_current == m_end)
		{
			return false;
		}
		else
		{
			id=*m_current;
			return true;
		}
	}
	bool Next(unsigned int &id)
	{
		m_current++;
		if (m_current == m_end)
		{
			return false;
		}
		else
		{
			id=*m_current;
			return true;
		}
	}
	bool End(unsigned int &id)
	{
		m_begin=m_intdata.begin();
		m_current=m_intdata.end();
		if (m_current == m_begin)
		{
			return false;
		}
		else
		{
			m_current--;
			id=*m_current;
			return true;
		}
	}
	bool Last(unsigned int &id)
	{
		
		if (m_current == m_begin)
		{
			return false;
		}
		else
		{
			m_current--;
			id=*m_current;
			return true;
		}
	}
	bool Find(unsigned int id)
	{
		std::set<unsigned int>::iterator p;
		p = m_intdata.find(id);
		if (p == m_intdata.end())
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	void Clear()
	{
		m_intdata.clear();
	}
	int Size()
	{
		return m_intdata.size();
	}
};
//��������ֶε����������ظ�
template<int count>
class CIndexInt
{
public:
	struct Int_
	{
		int	k[count];    //�����������
		int id;          //��Ӧ����ID���൱��rowid
	};
	struct Int_lt
	{
		bool operator()(const Int_ f1, const Int_ f2) const
		{
			int r=0;
			int i;

			for (i=0; i<count; i++)
			{
				r=f1.k[i]-f2.k[i];
				if (r != 0)
				{
					break;
				}
			}
			return r<0;
		}
	};

	CRepeatIndexBase<Int_,Int_lt> m_index;//�������ݣ����ظ�

public:
	CIndexInt()
	{
	}
	~CIndexInt()
	{
	}
	//����һ������:rowid,����...
	void Add(int id,...)
	{
		Int_ a_;
		va_list	intp;
		int i;

		a_.id=id;
		va_start(intp, id);
		for (i=0; i<count; i++)
		{
			a_.k[i]=va_arg(intp, int);
		}
		va_end(intp);    
		m_index.Add(a_);
		return;
	}
	//����ָ��������rowid��������ɺ�ֱ��ʹ�����ݣ���ɾ�����ô˷���
	bool Select(std::vector<int> &iset,int k,...)
	{
		Int_ a_;
		bool bret_,bret2_;
		int i;
		va_list	intp;
		iset.clear();
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, int);
		}
		va_end(intp);    
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.push_back(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//����ָ��������rowid  ���Һ�rowid����ɾ��ʱʹ��
	bool Select(CInt &iset,int k,...)
	{
		Int_ a_;
		bool bret_,bret2_;
		int i;
		va_list	intp;
		
		iset.Clear();
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, int);
		}
		va_end(intp);    
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.Add(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//����ָ�������������Ƿ���ڣ�m_end��Ϊ���һ�����ڴ�ֵ��λ�ã�����Nextȡ������ͬ��ֵ
	bool Find(int &rowid,int k,...)
	{
		Int_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, int);
		}
		va_end(intp);    
		bret_=m_index.Find(a_);
		rowid = a_.id;
		return bret_;
	}
	//����ָ�������������Ƿ���ڣ�m_endΪ��󣬿�����Nextֱ��������Ƚϲ��ң���ȡ��Χ��ֵ
	bool FindFirst(int &rowid,int k,...)
	{
		Int_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, int);
		}
		va_end(intp);    
		bret_=m_index.FindFirst(a_);
		rowid = a_.id;
		return bret_;
	}
	//ɾ��ָ������
	void Delete(int k,...)
	{
		Int_ a_;
		va_list	intp;
		int i;

		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, int);
		}
		va_end(intp);    
		m_index.Erase(a_);
		return;
	}
	//������������rowid����rowid��iset�д�����ɾ������
	void Delete(CInt iset,int k,...)
	{
		Int_ a_;
		bool bret_;
		va_list	intp;
		int i;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, int);
		}
		va_end(intp);    
		bret_=m_index.Find(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	//ɨ��ȫ����ɾ��rowid
	void Delete(CInt iset)
	{
		Int_ a_;
		bool bret_;
		bret_=m_index.First(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	bool First(int &id)
	{
		Int_ aa;
		if (!m_index.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Int_ aa;
		if (!m_index.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool End(int &id)
	{
		Int_ aa;
		if (!m_index.End(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Last(int &id)
	{
		Int_ aa;
		if (!m_index.Last(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_index.Clear();
	}
	int Size()
	{
		return m_index.Size();
	}
};

//��������ֶε�key�������ظ�
template<int count>
class CPkeyInt
{
public:
	struct Int_
	{
		int	k[count];    //�����������
		int id;          //��Ӧ����ID���൱��rowid
	};
	struct Int_lt
	{
		bool operator()(const Int_ f1, const Int_ f2) const
		{
			int r=0;
			int i;

			for (i=0; i<count; i++)
			{
				r=f1.k[i]-f2.k[i];
				if (r != 0)
				{
					break;
				}
			}
			return r<0;
		}
	};

	CUniqueIndexBase<Int_,Int_lt> m_key;//key���ݣ������ظ�

public:
	CPkeyInt()
	{
	}
	~CPkeyInt()
	{
	}
	//����һ������:rowid,����...
	void Add(int id,...)
	{
		Int_ a_;
		va_list	intp;
		int i;

		a_.id=id;
		va_start(intp, id);
		for (i=0; i<count; i++)
		{
			a_.k[i]=va_arg(intp, int);
		}
		va_end(intp);    
		m_key.Add(a_);
		return;
	}
	//����ָ��key��rowid  ɾ��ʱʹ��
	bool Select(CInt &iset,int k,...)
	{
		Int_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		iset.Clear();
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, int);
		}
		va_end(intp);    
		bret_=m_key.Find(a_);
		if (bret_)
		{
			iset.Add(a_.id);
		}
		return bret_;
	}
	bool Select(int &rid,int k,...)
	{
		Int_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, int);
		}
		va_end(intp);    
		bret_=m_key.Find(a_);
		if (bret_)
		{
			rid=a_.id;
		}
		return bret_;
	}
	//����ָ��key�������Ƿ����
	bool Find(int k,...)
	{
		Int_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, int);
		}
		va_end(intp);    
		bret_=m_key.Find(a_);
		return bret_;
	}
	//ɾ��ָ��key
	void Delete(int k,...)
	{
		Int_ a_;
		va_list	intp;
		int i;

		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, int);
		}
		va_end(intp);    
		m_key.Erase(a_);
		return;
	}
	bool First(int &id)
	{
		Int_ aa;
		if (!m_key.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Int_ aa;
		if (!m_key.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool End(int &id)
	{
		Int_ aa;
		if (!m_key.End(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Last(int &id)
	{
		Int_ aa;
		if (!m_key.Last(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_key.Clear();
	}
	int Size()
	{
		return m_key.Size();
	}
};


//��������ֶε����������ظ�
template<int count>
class CIndexUInt
{
public:
	struct Int_
	{
		unsigned int	k[count];    //�����������
		int id;          //��Ӧ����ID���൱��rowid
	};
	struct Int_lt
	{
		bool operator()(const Int_ f1, const Int_ f2) const
		{
			int r=0;
			int i;

			for (i=0; i<count; i++)
			{
				r=f1.k[i]-f2.k[i];
				if (r != 0)
				{
					break;
				}
			}
			return r<0;
		}
	};

	CRepeatIndexBase<Int_,Int_lt> m_index;//�������ݣ����ظ�

public:
	CIndexUInt()
	{
	}
	~CIndexUInt()
	{
	}
	//����һ������:rowid,����...
	void Add(int id,...)
	{
		Int_ a_;
		va_list	intp;
		int i;

		a_.id=id;
		va_start(intp, id);
		for (i=0; i<count; i++)
		{
			a_.k[i]=va_arg(intp, unsigned int);
		}
		va_end(intp);    
		m_index.Add(a_);
		return;
	}
	//����ָ��������rowid  ���Һ�ֱ��ʹ�����ݣ�����������
	bool Select(std::vector<int> &iset,unsigned int k,...)
	{
		Int_ a_;
		bool bret_,bret2_;
		int i;
		va_list	intp;
		
		iset.clear();
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, unsigned int);
		}
		va_end(intp);    
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.push_back(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//����ָ��������rowid ɾ��ʱʹ�ã���rowid����
	bool Select(CInt &iset,unsigned int k,...)
	{
		Int_ a_;
		bool bret_,bret2_;
		int i;
		va_list	intp;
		
		iset.Clear();
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, unsigned int);
		}
		va_end(intp);    
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.Add(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//����ָ�������������Ƿ���ڣ�m_end��Ϊ���һ�����ڴ�ֵ��λ�ã�����Nextȡ������ͬ��ֵ
	bool Find(int &rowid,unsigned int k,...)
	{
		Int_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp,unsigned int);
		}
		va_end(intp);    
		bret_=m_index.Find(a_);
		rowid = a_.id;
		return bret_;
	}
	//����ָ�������������Ƿ���ڣ�m_endΪ���һֵ��NEXTȡֻҪ��󣬿��԰���Χȡֵ
	bool FindFirst(int &rowid,unsigned int k,...)
	{
		Int_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp,unsigned int);
		}
		va_end(intp);    
		bret_=m_index.FindFirst(a_);
		rowid = a_.id;
		return bret_;
	}
	//ɾ��ָ������
	void Delete(unsigned int k,...)
	{
		Int_ a_;
		va_list	intp;
		int i;

		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp,unsigned int);
		}
		va_end(intp);    
		m_index.Erase(a_);
		return;
	}
	//������������rowid����rowid��iset�д�����ɾ������
	void Delete(CInt iset,unsigned int k,...)
	{
		Int_ a_;
		bool bret_;
		va_list	intp;
		int i;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp,unsigned int);
		}
		va_end(intp);    
		bret_=m_index.Find(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	//ɨ��ȫ����ɾ��rowid
	void Delete(CInt iset)
	{
		Int_ a_;
		bool bret_;
		bret_=m_index.First(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	bool First(int &id)
	{
		Int_ aa;
		if (!m_index.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Int_ aa;
		if (!m_index.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool End(int &id)
	{
		Int_ aa;
		if (!m_index.End(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Last(int &id)
	{
		Int_ aa;
		if (!m_index.Last(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_index.Clear();
	}
	int Size()
	{
		return m_index.Size();
	}
};

//��������ֶε�key�������ظ�
template<int count>
class CPkeyUInt
{
public:
	struct Int_
	{
		unsigned int	k[count];    //�����������
		int id;          //��Ӧ����ID���൱��rowid
	};
	struct Int_lt
	{
		bool operator()(const Int_ f1, const Int_ f2) const
		{
			int r=0;
			int i;

			for (i=0; i<count; i++)
			{
				r=f1.k[i]-f2.k[i];
				if (r != 0)
				{
					break;
				}
			}
			return r<0;
		}
	};

	CUniqueIndexBase<Int_,Int_lt> m_key;//key���ݣ������ظ�

public:
	CPkeyUInt()
	{
	}
	~CPkeyUInt()
	{
	}
	//����һ������:rowid,����...
	void Add(int id,...)
	{
		Int_ a_;
		va_list	intp;
		int i;

		a_.id=id;
		va_start(intp, id);
		for (i=0; i<count; i++)
		{
			a_.k[i]=va_arg(intp,unsigned int);
		}
		va_end(intp);    
		m_key.Add(a_);
		return;
	}
	//����ָ��key��rowid ɾ��ʱʹ��
	bool Select(CInt &iset,unsigned int k,...)
	{
		Int_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		iset.Clear();
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp,unsigned int);
		}
		va_end(intp);    
		bret_=m_key.Find(a_);
		if (bret_)
		{
			iset.Add(a_.id);
		}
		return bret_;
	}
	bool Select(int &rid,unsigned int k,...)
	{
		Int_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp,unsigned int);
		}
		va_end(intp);    
		bret_=m_key.Find(a_);
		if (bret_)
		{
			rid = a_.id;
		}
		return bret_;
	}
	//����ָ��key�������Ƿ����
	bool Find(unsigned int k,...)
	{
		Int_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp,unsigned int);
		}
		va_end(intp);    
		bret_=m_key.Find(a_);
		return bret_;
	}
	//ɾ��ָ��key
	void Delete(unsigned int k,...)
	{
		Int_ a_;
		va_list	intp;
		int i;

		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp,unsigned int);
		}
		va_end(intp);    
		m_key.Erase(a_);
		return;
	}
	bool First(int &id)
	{
		Int_ aa;
		if (!m_key.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Int_ aa;
		if (!m_key.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool End(int &id)
	{
		Int_ aa;
		if (!m_key.End(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Last(int &id)
	{
		Int_ aa;
		if (!m_key.Last(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_key.Clear();
	}
	int Size()
	{
		return m_key.Size();
	}
};


//����ַ��ֶε�����,���ظ�
template<int length,int count>
class CIndexCharF
{
public:
	struct Char_
	{
		char p[count][length];//����ַ�����
		int  id;              //�ڴ����rowid
	};
	struct Char_lt
	{
		bool operator()(const Char_ f1, const Char_ f2) const
		{
			int r=0;
			int i;

			for (i=0; i<count; i++)
			{
				r=strcmp(f1.p[i],f2.p[i]);
				if (r != 0)
				{
					break;
				}
			}
			return r<0;
		}
	};

	CRepeatIndexBase<Char_,Char_lt> m_index;  //�������ݣ����ظ�

public:
	CIndexCharF()
	{
	}
	~CIndexCharF()
	{
	}
	//����һ������:rowid,����...
	void Add(int id,char *p,...)
	{
		Char_ a_;
		va_list	charp;
		int i;

		a_.id=id;
		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		m_index.Add(a_);
		return;
	}
	//����ָ��������rowid  ֱ��ʹ�ò��ҵ�����ʱʹ�ã�����������
	bool Select(std::vector<int> &iset,char *p,...)
	{
		Char_ a_;
		bool bret_,bret2_;
		va_list charp;
		int i;
		
		iset.clear();
		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.push_back(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//����ָ��������rowid  ɾ��ʱʹ��
	bool Select(CInt &iset,char *p,...)
	{
		Char_ a_;
		bool bret_,bret2_;
		va_list charp;
		int i;

		iset.Clear();
		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.Add(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//����ָ�������������Ƿ���ڣ�m_end��Ϊ���һ�����ڴ�ֵ��λ�ã�����Nextȡ������ͬ��ֵ
	bool Find(int &rowid,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;

		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		bret_=m_index.Find(a_);
		rowid = a_.id;
		return bret_;
	}
	//����ָ�������������Ƿ���ڣ�m_endΪ���һֵ��NEXTȡֻҪ��󣬿��԰���Χȡֵ
	bool FindFirst(int &rowid,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;
		
		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		bret_=m_index.FindFirst(a_);
		rowid = a_.id;
		return bret_;
	}
	//ɾ��ָ������
	void Delete(char *p,...)
	{
		Char_ a_;
		va_list charp;
		int i;

		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		m_index.Erase(a_);
		return;
	}
	//������������rowid����rowid��iset�д�����ɾ������
	void Delete(CInt iset,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;
		
		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		bret_=m_index.Find(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	//ɨ��ȫ����ɾ��rowid
	void Delete(CInt iset)
	{
		Char_ a_;
		bool bret_;
		
		bret_=m_index.First(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	bool First(int &id)
	{
		Char_ aa;
		if (!m_index.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Char_ aa;
		if (!m_index.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool End(int &id)
	{
		Char_ aa;
		if (!m_index.End(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Last(int &id)
	{
		Char_ aa;
		if (!m_index.Last(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_index.Clear();
	}
	int Size()
	{
		return m_index.Size();
	}
};

//// ����ַ��ֶε�key,�����ظ�
template<int length,int count>
class CPkeyCharF
{
public:
	struct Char_
	{
		char p[count][length];//����ַ�����
		int  id;              //�ڴ����rowid
	};
	struct Char_lt
	{
		bool operator()(const Char_ f1, const Char_ f2) const
		{
			int r=0;
			int i;

			for (i=0; i<count; i++)
			{
				r=strcmp(f1.p[i],f2.p[i]);
				if (r != 0)
				{
					break;
				}
			}
			return r<0;
		}
	};

	CUniqueIndexBase<Char_,Char_lt> m_key;  //key���ݣ������ظ�

public:
	CPkeyCharF()
	{
	}
	~CPkeyCharF()
	{
	}
	//����һ������:id=rowid,����...
	void Add(int id,char *p,...)
	{
		Char_ a_;
		va_list	charp;
		int i;

		a_.id=id;
		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		m_key.Add(a_);
		return;
	}

	//����ָ��key��rowid ɾ��ʱʹ��
	bool Select(CInt &iset,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;

		iset.Clear();
		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		bret_=m_key.Find(a_);
		if (bret_)
		{
			iset.Add(a_.id);
		}
		return bret_;
	}
	//����ָ��key��rowid
	bool Select(int &rowid,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;
		
		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		bret_=m_key.Find(a_);
		if (bret_)
		{
			rowid =a_.id;
		}
		return bret_;
	}
	//����ָ��key��rowid
	bool GetRowId(int &rid,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;
		
		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		bret_=m_key.Find(a_);
		if (bret_)
		{
			rid =a_.id;
		}
		return bret_;
	}
	//����ָ��key�Ƿ����
	bool Find(char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;

		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		bret_=m_key.Find(a_);
		return bret_;
	}
	//ɾ��ָ��key
	void Delete(char *p,...)
	{
		Char_ a_;
		va_list charp;
		int i;

		CBF_Tools::StringCopy(a_.p[0],length-1,p);
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			CBF_Tools::StringCopy(a_.p[i+1],length-1,va_arg(charp,char*));
		}
		va_end(charp);
		m_key.Erase(a_);
		return;
	}
	bool First(int &id)
	{
		Char_ aa;
		if (!m_key.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Char_ aa;
		if (!m_key.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool End(int &id)
	{
		Char_ aa;
		if (!m_key.End(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Last(int &id)
	{
		Char_ aa;
		if (!m_key.Last(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_key.Clear();
	}
	int Size()
	{
		return m_key.Size();
	}
};

//����ַ��ֶε�������ע��������ļ�ֵָ�����Ķ�Ӧ�ֶΣ�ͬʱ��������deque����Ϊvector��ַ���

template<int count>
class CPkeyCharV
{
public:
	struct Char_
	{
		char *p[count];//����ַ�����
		int  id;              //�ڴ����rowid
	};
	struct Char_lt
	{
		bool operator()(const Char_ f1, const Char_ f2) const
		{
			int r=0;
			int i;

			for (i=0; i<count; i++)
			{
				r=strcmp(f1.p[i],f2.p[i]);
				if (r != 0)
				{
					break;
				}
			}
			return r<0;
		}
	};

	CUniqueIndexBase<Char_,Char_lt> m_key;  //key���ݣ������ظ�

public:
	CPkeyCharV()
	{
	}
	~CPkeyCharV()
	{
	}
	//����һ������:id=rowid,����...
	void Add(int id,char *p,...)
	{
		Char_ a_;
		va_list	charp;
		int i;

		a_.id=id;
		a_.p[0]=p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1] = va_arg(charp,char*);
		}
		va_end(charp);
		m_key.Add(a_);
		return;
	}
	//����ָ��key��rowid  ɾ��ʱʹ��
	bool Select(CInt &iset,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;

		iset.Clear();
		a_.p[0] =p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1]= va_arg(charp,char*);
		}
		va_end(charp);
		bret_=m_key.Find(a_);
		if (bret_)
		{
			iset.Add(a_.id);
		}
		return bret_;
	}
	//����ָ��key��rowid
	bool Select(int &rid,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;
		
		a_.p[0] =p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1]= va_arg(charp,char*);
		}
		va_end(charp);
		bret_=m_key.Find(a_);
		if (bret_)
		{
			rid = a_.id;
		}
		return bret_;
	}
	//����ָ��key��rowid
	bool GetRowId(int &rid,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;
		
		a_.p[0] =p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1] = va_arg(charp,char*);
		}
		va_end(charp);
		bret_=m_key.Find(a_);
		if (bret_)
		{
			rid =a_.id;
		}
		return bret_;
	}
	//����ָ��key�Ƿ����
	bool Find(char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;

		a_.p[0] = p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1] = va_arg(charp,char*);
		}
		va_end(charp);
		bret_=m_key.Find(a_);
		return bret_;
	}
	//ɾ��ָ��key
	void Delete(char *p,...)
	{
		Char_ a_;
		va_list charp;
		int i;

		a_.p[0]=p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1]=va_arg(charp,char*);
		}
		va_end(charp);
		m_key.Erase(a_);
		return;
	}
	bool First(int &id)
	{
		Char_ aa;
		if (!m_key.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Char_ aa;
		if (!m_key.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	char *FirstKey(int &id)
	{
		Char_ aa;
		if (!m_key.First(aa))
		{
			return NULL;
		}
		id = aa.id;
		return aa.p[0];
	}
	char *NextKey(int &id)
	{
		Char_ aa;
		if (!m_key.Next(aa))
		{
			return NULL;
		}
		id = aa.id;
		return aa.p[0];
	}
	bool End(int &id)
	{
		Char_ aa;
		if (!m_key.End(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Last(int &id)
	{
		Char_ aa;
		if (!m_key.Last(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_key.Clear();
	}
	int Size()
	{
		return m_key.Size();
	}
};

//����ַ��ֶε�������ע���������ֵָ�����Ķ�Ӧ�ֶ�
template<int count>
class CIndexVarChar
{
public:
	struct Char_
	{
		char *p[count];//����ַ�����
		int  id;              //�ڴ����rowid
	};
	struct Char_lt
	{
		bool operator()(const Char_ f1, const Char_ f2) const
		{
			int r=0;
			int i;

			for (i=0; i<count; i++)
			{
				r=strcmp(f1.p[i],f2.p[i]);
				if (r != 0)
				{
					break;
				}
			}
			return r<0;
		}
	};

	CRepeatIndexBase<Char_,Char_lt> m_index;  //�������ݣ����ظ�

public:
	CIndexVarChar()
	{
	}
	~CIndexVarChar()
	{
	}
	//����һ������:id=rowid,����...
	void Add(int id,char *p,...)
	{
		Char_ a_;
		va_list	charp;
		int i;

		a_.id=id;
		a_.p[0]=p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1] = va_arg(charp,char*);
		}
		va_end(charp);
		m_index.Add(a_);
		return;
	}
	//����ָ����rowid  ֱ��ʹ������ʱʹ��
	bool Select(std::vector<int> &iset,char *p,...)
	{
		Char_ a_;
		bool bret_,bret2_;
		va_list charp;
		int i;
		
		iset.clear();
		a_.p[0] =p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1]= va_arg(charp,char*);
		}
		va_end(charp);
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.push_back(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//����ָ����rowid  ɾ��ʱʹ��
	bool Select(CInt &iset,char *p,...)
	{
		Char_ a_;
		bool bret_,bret2_;
		va_list charp;
		int i;

		iset.Clear();
		a_.p[0] =p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1]= va_arg(charp,char*);
		}
		va_end(charp);
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.Add(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}

	//ɾ��ָ��
	void Delete(char *p,...)
	{
		Char_ a_;
		va_list charp;
		int i;

		a_.p[0]=p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1]=va_arg(charp,char*);
		}
		va_end(charp);
		m_index.Erase(a_);
		return;
	}
	//ɾ��������������������rowid,��rowid��iset�д�����ɾ������
	void Delete(CInt iset,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list	intp;
		int i;
		
		a_.p[0]=p;
		va_start(intp, p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1]=va_arg(intp, char *);
		}
		va_end(intp);    
		bret_=m_index.Find(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	//ɨ��ȫ����ɾ��rowid
	void Delete(CInt iset)
	{
		Char_ a_;
		bool bret_;
		bret_=m_index.First(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	//����ָ�������������Ƿ���ڣ�m_end��Ϊ���һ�����ڴ�ֵ��λ�ã�����Nextȡ������ͬ��ֵ
	bool Find(int &rowid,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;
		
		a_.p[0] = p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1] = va_arg(charp,char*);
		}
		va_end(charp);
		bret_=m_index.Find(a_);
		rowid = a_.id;
		return bret_;
	}
	//����ָ�������������Ƿ���ڣ�m_endΪ���һֵ��NEXTȡֻҪ��󣬿��԰���Χȡֵ
	bool FindFirst(int &rowid,char *p,...)
	{
		Char_ a_;
		bool bret_;
		va_list charp;
		int i;
		
		a_.p[0] = p;
		va_start(charp,p);
		for (i=0; i<count-1; i++)
		{
			a_.p[i+1] = va_arg(charp,char*);
		}
		va_end(charp);
		bret_=m_index.FindFirst(a_);
		rowid = a_.id;
		return bret_;
	}
	bool First(int &id)
	{
		Char_ aa;
		if (!m_index.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Char_ aa;
		if (!m_index.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool End(int &id)
	{
		Char_ aa;
		if (!m_index.End(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Last(int &id)
	{
		Char_ aa;
		if (!m_index.Last(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_index.Clear();
	}
	int Size()
	{
		return m_index.Size();
	}
};
//һ���ַ��ֶε�����
class CIndexCharV
{
public:
	struct Char_
	{
		char *p;  //�ַ�����ֵ
		int  id;  //rowid
	};
	struct Char_lt
	{
		bool operator()(const Char_ f1, const Char_ f2) const
		{
			int r=0;

			r=strcmp(f1.p,f2.p);
			return r<0;
		}
	};

	CRepeatIndexBase<Char_,Char_lt> m_index;////�������ݣ����ظ�

public:
	CIndexCharV()
	{
	}
	~CIndexCharV()
	{
	}
	//����һ������
	void Add(int id,char *p)
	{
		Char_ a_;
		
		a_.id=id;
		a_.p=p;
		m_index.Add(a_);
		return;
	}
	//������������rowid,����iset��  ֱ��ʹ������ʱʹ��
	bool Select(std::vector<int> &iset,char *p)
	{
		Char_ a_;
		bool bret_,bret2_;
		
		iset.clear();
		a_.p=p;
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.push_back(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//������������rowid,����iset��  ɾ��ʱʹ��
	bool Select(CInt &iset,char *p)
	{
		Char_ a_;
		bool bret_,bret2_;
		
		iset.Clear();
		a_.p=p;
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.Add(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//����ָ�������������Ƿ���ڣ�m_end��Ϊ���һ�����ڴ�ֵ��λ�ã�����Nextȡ������ͬ��ֵ
	bool Find(int &rowid,char *p)
	{
		Char_ a_;
		bool bret_;
		
		a_.p=p;
		bret_=m_index.Find(a_);
		rowid = a_.id;
		return bret_;
	}

	//����ָ�������������Ƿ���ڣ�m_endΪ���һֵ��NEXTȡֻҪ��󣬿��԰���Χȡֵ
	bool FindFirst(int &rowid,char *p)
	{
		Char_ a_;
		bool bret_;
		
		a_.p=p;
		bret_=m_index.FindFirst(a_);
		rowid = a_.id;
		return bret_;
	}
	//ɾ������
	void Delete(char *p)
	{
		Char_ a_;

		a_.p=p;
		m_index.Erase(a_);
		return;
	}
	//ɾ��������������������rowid,��rowid��iset�д�����ɾ������
	void Delete(CInt iset,char *p)
	{
		Char_ a_;
		bool bret_;
		
		a_.p=p;
		bret_=m_index.Find(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	//ɨ��ȫ����ɾ��rowid
	void Delete(CInt iset)
	{
		Char_ a_;
		bool bret_;
		
		bret_=m_index.First(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	bool First(int &id)
	{
		Char_ aa;
		if (!m_index.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Char_ aa;
		if (!m_index.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool End(int &id)
	{
		Char_ aa;
		if (!m_index.End(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Last(int &id)
	{
		Char_ aa;
		if (!m_index.Last(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_index.Clear();
	}
	int Size()
	{
		return m_index.Size();
	}
};

//���64λ�޷��������ֶε����������ظ�
template<int count>
class CIndexUint64
{
public:
	struct Int64_
	{
		UINT64_	k[count];    //�����������
		int id;          //��Ӧ����ID���൱��rowid
	};
	struct Int64_lt
	{
		bool operator()(const Int64_ f1, const Int64_ f2) const
		{
			INT64_ r=0;
			int i;

			for (i=0; i<count; i++)
			{
				r=f1.k[i]-f2.k[i];
				if (r != 0)
				{
					break;
				}
			}
			return r<0;
		}
	};

	CRepeatIndexBase<Int64_,Int64_lt> m_index;//�������ݣ����ظ�

public:
	CIndexUint64()
	{
	}
	~CIndexUint64()
	{
	}
	//����һ������:rowid,����...
	void Add(int id,UINT64_ ind,...)
	{
		Int64_ a_;
		va_list	intp;
		int i;

		a_.id=id;
		a_.k[0]=  ind;
		va_start(intp, ind);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		m_index.Add(a_);
		return;
	}
	//����ָ��������rowid  ֱ��ʹ������ʱʹ��
	bool Select(std::vector<int> &iset,UINT64_ k,...)
	{
		Int64_ a_;
		bool bret_,bret2_;
		int i;
		va_list	intp;
		
		iset.clear();
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.push_back(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//����ָ��������rowid  ɾ��ʱʹ��
	bool Select(CInt &iset,UINT64_ k,...)
	{
		Int64_ a_;
		bool bret_,bret2_;
		int i;
		va_list	intp;
		
		iset.Clear();
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		bret2_=bret_=m_index.Find(a_);
		while (bret_)
		{
			iset.Add(a_.id);
			bret_=m_index.Next(a_);
		}
		return bret2_;
	}
	//����ָ�������������Ƿ���ڣ�m_end��Ϊ���һ�����ڴ�ֵ��λ�ã�����Nextȡ������ͬ��ֵ
	bool Find(int &rowid,UINT64_ k,...)
	{
		Int64_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		bret_=m_index.Find(a_);
		rowid = a_.id;
		return bret_;
	}
	//����ָ�������������Ƿ���ڣ�m_endΪ���һֵ��NEXTȡֻҪ��󣬿��԰���Χȡֵ
	bool FindFirst(int &rowid,UINT64_ k,...)
	{
		Int64_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		bret_=m_index.FindFirst(a_);
		rowid = a_.id;
		return bret_;
	}
	//ɾ��ָ������
	void Delete(UINT64_ k,...)
	{
		Int64_ a_;
		va_list	intp;
		int i;

		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		m_index.Erase(a_);
		return;
	}
	//������������rowid����rowid��iset�д�����ɾ������
	void Delete(CInt iset,UINT64_ k,...)
	{
		Int64_ a_;
		bool bret_;
		va_list	intp;
		int i;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		bret_=m_index.Find(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	//ɨ��ȫ����ɾ��rowid
	void Delete(CInt iset)
	{
		Int64_ a_;
		bool bret_;
		
		bret_=m_index.First(a_);
		while (bret_)
		{
			if (iset.Find(a_.id))
			{
				m_index.EraseOne();
			}
			bret_=m_index.Next(a_);
		}
	}
	bool First(int &id)
	{
		Int64_ aa;
		if (!m_index.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Int64_ aa;
		if (!m_index.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_index.Clear();
	}
	int Size()
	{
		return m_index.Size();
	}
};


//���64λ�޷��������ֶε�key�������ظ�
template<int count>
class CPkeyUint64
{
public:
	struct Int64_
	{
		UINT64_	k[count];    //�����������
		int id;          //��Ӧ����ID���൱��rowid
	};
	struct Int64_lt
	{
		bool operator()(const Int64_ f1, const Int64_ f2) const
		{
			INT64_ r=0;
			int i;

			for (i=0; i<count; i++)
			{
				r=f1.k[i]-f2.k[i];
				if (r != 0)
				{
					break;
				}
			}
			return r<0;
		}
	};

	CUniqueIndexBase<Int64_,Int64_lt> m_key;//key���ݣ������ظ�

public:
	CPkeyUint64()
	{
	}
	~CPkeyUint64()
	{
	}
	//����һ������:rowid,����...
	void Add(int id,UINT64_ ind,...)
	{
		Int64_ a_;
		va_list	intp;
		int i;

		a_.id=id;
		a_.k[0]=ind;
		va_start(intp, ind);
		for (i=0; i<count-1; i++)
		{
			a_.k[i=1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		m_key.Add(a_);
		return;
	}
	//����ָ��key��rowid  ɾ��ʱʹ��
	bool Select(CInt &iset,UINT64_ k,...)
	{
		Int64_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		iset.Clear();
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		bret_=m_key.Find(a_);
		if (bret_)
		{
			iset.Add(a_.id);
		}
		return bret_;
	}
	//����ָ��key��rowid
	bool Select(int  &rid,UINT64_ k,...)
	{
		Int64_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		bret_=m_key.Find(a_);
		if (bret_)
		{
			rid =a_.id;
		}
		return bret_;
	}
	//����ָ��key�������Ƿ����
	bool Find(UINT64_ k,...)
	{
		Int64_ a_;
		bool bret_;
		int i;
		va_list	intp;
		
		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		bret_=m_key.Find(a_);
		return bret_;
	}
	//ɾ��ָ��key
	void Delete(UINT64_ k,...)
	{
		Int64_ a_;
		va_list	intp;
		int i;

		a_.k[0]=k;
		va_start(intp, k);
		for (i=0; i<count-1; i++)
		{
			a_.k[i+1]=va_arg(intp, UINT64_);
		}
		va_end(intp);    
		m_key.Erase(a_);
		return;
	}
	bool First(int &id)
	{
		Int64_ aa;
		if (!m_key.First(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	bool Next(int &id)
	{
		Int64_ aa;
		if (!m_key.Next(aa))
		{
			return false;
		}
		id = aa.id;
		return true;
	}
	void Clear()
	{
		m_key.Clear();
	}
	int Size()
	{
		return m_key.Size();
	}
};


//�ڴ��
template<typename Record>
class CMemTableNew  
{
public:
	//songfree 20180419 ��Ϊdeque����Ϊvector�洢ʱ������Ԫ��ʱԭ���ĵ�ַΪ�䣬ʹ��PKEYCHARV��ָ����Ϊ����ʱ�����á�
	//typedef std::vector<Record> VECTOR_;       //���屣���ڴ�����ݵ����ͣ�vector���±��൱��rowid
	typedef std::deque<Record> VECTOR_;       //���屣���ڴ�����ݵ����ͣ�deque���±��൱��rowid
	std::list<int>    m_rowidpool;              //����ɾ�����ڴ������ID���൱��rowid���´�����ʱֱ��ʹ��         
	VECTOR_      m_table;                  //������
	std::vector<bool> m_inuseid;                //rowid��Ӧ�������Ƿ�ɾ��
	int  m_current;
public:
	
	CMemTableNew()
	{
		m_current = 0;
	}
	~CMemTableNew()
	{
		Clear();
	}
	//����¼ɾ��ʱ�����˵�
    Record *At(int index)
	{
		if (index <0 || index >m_table.size()-1)
		{
			return NULL;
		}
		if (m_inuseid[index]) //û��ɾ��
		{
			return &(m_table.at(index));
		}
		else
		{
			return NULL;
		}
		
	}
	void Clear()
	{
		m_table.clear();
		m_inuseid.clear();
		m_rowidpool.clear();
	}
	int Add(Record& rt)
	{
		int id;
		if (m_rowidpool.size() > 0)
		{
			id=m_rowidpool.front();
			m_rowidpool.pop_front();
			m_table[id]=rt;
			m_inuseid[id]=true;
		}
		else
		{
			id=m_table.size();
			m_table.push_back(rt);
			m_inuseid.push_back(true);
		}
		return id;
	}
	void Update(int id,Record& rt,bool logged=false)
	{
		m_table[id]=rt;
	}
	void GetById(int id,Record& rt)
	{
		rt=m_table[id];
	}
	void Delete(int id)
	{
		m_rowidpool.push_back(id);
		m_inuseid[id]=false;
	}
	bool First(Record& rt)
	{
		m_current = 0;
		for (int i=0;i<m_table.size();i++)
		{
			if (m_inuseid[i])
			{
				rt = m_table[i];
				m_current = i;
				return true;
			}
		}
		return false;
	}
	Record *First()
	{
		m_current = 0;
		for (int i=0;i<m_table.size();i++)
		{
			if (m_inuseid[i])
			{
				m_current = i;
				return &(m_table[i]);
			}
		}
		return NULL;
	}
	bool Next(Record& rt)
	{
		m_current++;
		for (;m_current<m_table.size();m_current++)
		{
			if (m_inuseid[m_current])
			{
				rt = m_table[m_current];
				return true;
			}
		}
		return false;
	}
	Record *Next()
	{
		m_current++;
		for (;m_current<m_table.size();m_current++)
		{
			if (m_inuseid[m_current])
			{
				return &(m_table[m_current]);
			}
		}
		return NULL;
	}
	//����ɾ���ļ�¼
	int AllSize()
	{
		return m_table.size();
	}
	//������ɾ���ļ�¼
	int RealSize()
	{
		return m_table.size()-m_rowidpool.size();
	}
	//������ɾ���ļ�¼
	int Size()
	{
		return m_table.size()-m_rowidpool.size();
	}
};
//�ڴ��
template<typename Record>
class CMemTable  
{
public:
	
	typedef std::vector<Record> VECTOR_;       //���屣���ڴ�����ݵ����ͣ�vector���±��൱��rowid
//	typedef std::deque<Record> VECTOR_;       //���屣���ڴ�����ݵ����ͣ�vector���±��൱��rowid
	std::list<int>    m_rowidpool;              //����ɾ�����ڴ������ID���൱��rowid���´�����ʱֱ��ʹ��         
	VECTOR_      m_table;                  //������
	std::vector<bool> m_inuseid;                //rowid��Ӧ�������Ƿ�ɾ��
	unsigned int  m_current;
public:
	
	CMemTable()
	{
		m_current = 0;
	}
	~CMemTable()
	{
		Clear();
	}
	//����¼ɾ��ʱ�����˵�
    Record *At(int index)
	{
		if (index <0 || index >m_table.size()-1)
		{
			return NULL;
		}
		if (m_inuseid[index]) //û��ɾ��
		{
			return &(m_table.at(index));
		}
		else
		{
			return NULL;
		}
		
	}
	void Clear()
	{
		m_table.clear();
		m_inuseid.clear();
		m_rowidpool.clear();
	}
	int Add(Record& rt)
	{
		int id;
		if (m_rowidpool.size() > 0)
		{
			id=m_rowidpool.front();
			m_rowidpool.pop_front();
			m_table[id]=rt;
			m_inuseid[id]=true;
		}
		else
		{
			id=m_table.size();
			m_table.push_back(rt);
			m_inuseid.push_back(true);
		}
		return id;
	}
	void Update(int id,Record& rt,bool logged=false)
	{
		m_table[id]=rt;
	}
	void GetById(int id,Record& rt)
	{
		rt=m_table[id];
	}
	void Delete(int id)
	{
		m_rowidpool.push_back(id);
		m_inuseid[id]=false;
	}
	bool First(Record& rt)
	{
		m_current = 0;
		for (unsigned int i=0;i<m_table.size();i++)
		{
			if (m_inuseid[i])
			{
				rt = m_table[i];
				m_current = i;
				return true;
			}
		}
		return false;
	}
	Record *First()
	{
		m_current = 0;
		for (int i=0;i<m_table.size();i++)
		{
			if (m_inuseid[i])
			{
				m_current = i;
				return &(m_table[i]);
			}
		}
		return NULL;
	}
	bool Next(Record& rt)
	{
		m_current++;
		for (;m_current<m_table.size();m_current++)
		{
			if (m_inuseid[m_current])
			{
				rt = m_table[m_current];
				return true;
			}
		}
		return false;
	}
	Record *Next()
	{
		m_current++;
		for (;m_current<m_table.size();m_current++)
		{
			if (m_inuseid[m_current])
			{
				return &(m_table[m_current]);
			}
		}
		return NULL;
	}
	//����ɾ���ļ�¼
	int AllSize()
	{
		return m_table.size();
	}
	//������ɾ���ļ�¼
	int RealSize()
	{
		return m_table.size()-m_rowidpool.size();
	}
	//������ɾ���ļ�¼
	int Size()
	{
		return m_table.size()-m_rowidpool.size();
	}
};

//�����ֶλ���
class CIndex_Field_Base
{
public:
	int   m_nRowId;//rowid������rowid

	//��Ҫʵ�ֵ��ֶ������ȽϷ���
	virtual bool operator<(const CIndex_Field_Base& field) const
	{
		return false;
	}
};

//���ظ�����������
template<typename Record>
class CUniqueFieldIndexBase
{
public:
	typedef std::set<Record> SET_;
	typedef typename SET_::iterator LP_SET;
	SET_    m_index;//�������ݣ�Record�������ظ�
	LP_SET  m_current;//��ǰ����
public:
	CUniqueFieldIndexBase()
	{
	}
	~CUniqueFieldIndexBase()
	{
		Clear();
	}
	void Clear()
	{
		m_index.clear();
	}
	bool First(Record& rt)
	{
		m_current = m_index.begin();
		if(m_current == m_index.end())
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	bool Next(Record& rt)
	{
		m_current++;
		if(m_current == m_index.end())
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	bool End(Record& rt)
	{
		m_current = m_index.end();
		if(m_current == m_index.begin())
		{
			return false;
		}
		else
		{
			m_current--;
			rt = *m_current;
			return true;
		}
	}
	bool Last(Record& rt)
	{
		if(m_current == m_index.begin())
		{
			return false;
		}
		else
		{
			m_current--;
			rt = *m_current;
			return true;
		}
	}
	bool Find(Record& rt)
	{
		m_current = m_index.find(rt);
		if(m_current == m_index.end())
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	void Add(Record& rt)
	{
// #ifdef _GCC
// 		Erase(rt);
// #endif
		pair<LP_SET,bool> r = m_index.insert(rt);
// #ifndef _GCC
// 		if(!r.second) *r.first = rt;
// #endif
	}
	void Erase(Record& rt)
	{
		m_index.erase(rt);
	}
	void EraseOne()
	{
		m_index.erase(m_current++);
	}
	int Size()
	{
		return m_index.size();
	}
};


//�ظ�����������
template<typename Record>
class CRepeatFieldIndexBase
{
public:
	typedef std::multiset<Record> MULTISET_;
	typedef typename MULTISET_::iterator LP_MULTISET;
	MULTISET_    m_index;   //�������� Record�����ж��
	LP_MULTISET  m_current; 
	LP_MULTISET  m_end;
	LP_MULTISET  m_begin;
	bool         m_bDroped;

public:
	CRepeatFieldIndexBase()
	{
		m_bDroped=false;
	}
	~CRepeatFieldIndexBase()
	{
		Clear();
	}
	void Clear()
	{
		m_index.clear();
	}
	bool End(Record& rt)
	{
		m_begin = m_index.begin();
		m_current = m_index.end();
		if(m_current == m_end)
		{
			return false;
		}
		else 
		{
			m_current--;
			rt = *m_current;
			return true;
		}
	}
	bool Last(Record& rt)
	{
		if (!m_bDroped)
		{
			m_current--;
		}
		else
		{
			m_bDroped=false;
		}
		if(m_current == m_begin)
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	bool First(Record& rt)
	{
		m_current = m_index.begin();
		m_end=m_index.end();
		if(m_current == m_end)
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	bool Next(Record& rt)
	{
		if (!m_bDroped)
		{
			m_current++;
		}
		else
		{
			m_bDroped=false;
		}
		if(m_current == m_end)
		{
			return false;
		}
		else
		{
			rt = *m_current;
			return true;
		}
	}
	//���ҵ�һ����λ�ú����һ�����ڴ�ֵ��λ�ã�NEXT��������֮��ȡ�ö����ֵͬ������
	bool Find(Record& rt)
	{
		m_bDroped=false;
		m_current = m_index.find(rt);
		m_end=m_index.upper_bound(rt);//��һ�����ڴ�ֵ��λ�ã��Ժ����Nextʹ��
		if(m_current == m_end)
		{
			return false;
		}
		else
		{
			if (m_current == m_index.end())
			{
				return false;
			}
			else
			{
				rt = *m_current;
				return true;
			}
		}
	}
	//���ҵ�һ����λ�ã�NEXT���Լ����ң�ֻҪ������
	bool FindFirst(Record& rt)
	{
		m_bDroped=false;
		m_current = m_index.find(rt);
		m_end= m_index.end();
		if(m_current == m_end)
		{
			return false;
		}
		else
		{
			if (m_current == m_index.end())
			{
				return false;
			}
			else
			{
				rt = *m_current;
				return true;
			}
		}
		
	}
	void Add(Record& rt)
	{
		m_index.insert(rt);
	}

	void EraseOne()
	{
		m_index.erase(m_current++);
		m_bDroped=true;
	}

	void Erase(Record& rt)
	{
		m_index.erase(rt);
	}
	int Size()
	{
		return m_index.size();
	}
};

template<typename Record>
class CKeyField
{
public:
	CUniqueFieldIndexBase<Record> m_key;  //key���ݣ������ظ�

public:
	CKeyField()
	{
	}
	~CKeyField()
	{
	}
	//����һ������:id=rowid,����...
	void Add(Record &rf)
	{
		m_key.Add(rf);
		return;
	}
	bool Select(Record &rf)
	{
		return m_key.Find(rf);
	}
	
	//����ָ��key�Ƿ����
	bool Find(Record &rf)
	{
		return m_key.Find(rf);
	}
	//ɾ��ָ��key
	void Delete(Record &rf)
	{
		m_key.Erase(rf);
		return;
	}
	void EraseOne()
	{
		m_key.EraseOne();
		return;
	}
	bool First(Record &rf)
	{
		if (!m_key.First(rf))
		{
			return false;
		}
		return true;
	}
	bool Next(Record &rf)
	{
		if (!m_key.Next(rf))
		{
			return false;
		}
		return true;
	}
	bool End(Record &rf)
	{
		
		if (!m_key.End(rf))
		{
			return false;
		}
		return true;
	}
	bool Last(Record &rf)
	{
		if (!m_key.Last(rf))
		{
			return false;
		}
		return true;
	}
	void Clear()
	{
		m_key.Clear();
	}
	int Size()
	{
		return m_key.Size();
	}
};

template<typename Record>
class CIndexField
{
public:
	CRepeatFieldIndexBase<Record> m_index;  //�������ݣ����ظ�

public:
	CIndexField()
	{
	}
	~CIndexField()
	{
	}
	//����һ������:rowid,����...
	void Add(Record &rf)
	{
		m_index.Add(rf);
		return;
	}
	
	//����ָ�������������Ƿ���ڣ�m_end��Ϊ���һ�����ڴ�ֵ��λ�ã�����Nextȡ������ͬ��ֵ
	bool Find(Record &rf)
	{
		return m_index.Find(rf);
	}
	//����ָ�������������Ƿ���ڣ�m_endΪ���һֵ��NEXTȡֻ����󣬿��԰���Χȡֵ
	bool FindFirst(Record &rf)
	{
		return m_index.FindFirst(rf);
	}
	//ɾ��ָ������
	void Delete(Record &rf)
	{
		Record tmp;
		bool bret = Find(rf);
		while (bret)
		{
			m_index.EraseOne();
			bret = Next(tmp);
		}
		return;
	}
	void EraseOne()
	{
		m_index.EraseOne();
	}
	bool First(Record &rf)
	{
		if (!m_index.First(rf))
		{
			return false;
		}
		return true;
	}
	bool Next(Record &rf)
	{
		if (!m_index.Next(rf))
		{
			return false;
		}
		return true;
	}
	bool End(Record &rf)
	{
		if (!m_index.End(rf))
		{
			return false;
		}
		return true;
	}
	bool Last(Record &rf)
	{
//		CIndex_Field_Base rf;
		if (!m_index.Last(rf))
		{
			return false;
		}
		return true;
	}
	void Clear()
	{
		m_index.Clear();
	}
	int Size()
	{
		return m_index.Size();
	}

};


template<typename Record>
class CInstanceList
{
public:
	CInstanceList()
	{
		
	}
	virtual ~CInstanceList()
	{
		
	}
	int Size()
	{
		return m_table.RealSize();
	}
	Record * Find(int id)
	{
		CInt iset;
		if (!m_key.Select(iset,id))
		{
			return NULL;
		}
		int rid;
		iset.First(rid);
		return m_table.m_table[id];
	}
	bool Delete(int id)
	{
		CInt iset;
		if (!m_key.Select(iset,id))
		{
			return false;
		}
		m_key.Delete(id);
		m_table.Delete(id);
		return true;
	}
	int  Insert(Record *point)
	{
		int id = m_table.Add(point);
		CInt iset;
		if (!m_key.Select(iset,id))
		{
			m_key.Add(id,id);
		}
		else
		{
			m_key.Delete(id);
			m_key.Add(id,id);
		}
		return id;
	}
protected:
	
	CMemTable <Record *> m_table;
	CPkeyInt<1>                     m_key;   //rowid����
};




class CMTblSample
{
public:
	CMTblSample();
	virtual ~CMTblSample();
	
	struct S_TBL_SAMPLE
	{
		unsigned short nNodeId;        
		char           cNodePrivateId; 
		int            data;
	};
public:
	
	void Test()
	{
		CMTblSample dbl;
		S_TBL_SAMPLE dd;
		int i;
		
		for (i=0;i<100;i++)
		{
			dd.nNodeId = i;
			dd.cNodePrivateId = i;
			dbl.Insert(dd);
		}
		for (i=0;i<100;i++)
		{
			dd.nNodeId = i;
			dd.cNodePrivateId = 0;
			dbl.Insert(dd);
		}
		vector<S_TBL_SAMPLE>dlist;
		dbl.SelectByNode(1,dlist);
		
		for (int j=0;j<(int)dlist.size();j++)
		{
			printf("NODEID=%d PRIVATEID=%d\n",dlist[j].nNodeId,dlist[j].cNodePrivateId);
		}
		dbl.SelectPrivateid(1,1,dd);
		printf("NODEID=%d PRIVATEID=%d\n",dd.nNodeId,dd.cNodePrivateId);
	}
	bool Update(S_TBL_SAMPLE &drtp)
	{
		CInt iset;
		int rid;
		if (!m_pkey.Select(rid,drtp.nNodeId,drtp.cNodePrivateId))
		{
			return false;
		}
		
		m_table.m_table[rid] = drtp;
		return true;
	}
	bool Delete(int nodeid,int privateid)
	{
		CInt iset;
		if (!m_pkey.Select(iset,nodeid,privateid))
		{
			return false;
		}
		int id;
		iset.First(id);
		m_pkey.Delete(nodeid,privateid);
		m_index_node.Delete(iset,nodeid);
		m_table.Delete(id);
		return true;
	}
	bool SelectPrivateid(int nodeid,int privateid,S_TBL_SAMPLE &drtp)
	{
		CInt iset;
		if (!m_pkey.Select(iset,nodeid,privateid))
		{
			return false;
		}
		int id;
		iset.First(id);
		drtp = m_table.m_table[id];
		return true;
	}
	//���ȡֵ������������������������
	bool SelectByNode(int nodeid, vector<S_TBL_SAMPLE *> &drtp)
	{
		std::vector<int> iset;
		if (!m_index_node.Select(iset,nodeid))
		{
			return false;
		}
		for (unsigned int i=0; i<iset.size();i++)
		{
			drtp.push_back(&(m_table.m_table[iset[i]]));
		}
		return true;
	}
	//���ȡֵ��rowid���򣬿��ܲ�����Ҫ��
	bool SelectByNode(int nodeid, vector<S_TBL_SAMPLE> &drtp)
	{
		CInt iset;
		if (!m_index_node.Select(iset,nodeid))
		{
			return false;
		}
		int id;
		bool bRet;
		bRet = iset.First(id);
		while (bRet)
		{
			drtp.push_back(m_table.m_table[id]);
			bRet = iset.Next(id);
		}
		return true;
	}
	bool Insert(S_TBL_SAMPLE drtp)
	{
		int id;
		//ͨ���������ң�������������
		if (!m_pkey.Find(drtp.nNodeId,drtp.cNodePrivateId))
		{
			id = m_table.Add(drtp);//���ӵ���
			m_pkey.Add(id,drtp.nNodeId,drtp.cNodePrivateId);//��������
			m_index_node.Add(id,drtp.nNodeId);//��������
			return true;
		}
		return false;
	}
protected:
	
	CMemTable <S_TBL_SAMPLE> m_table;        //�ڴ��
	list<int>                m_queryResult;  //��ѯ���rowid�б�
	CIndexInt<1>             m_index_node;   //id����
	CPkeyInt<2>              m_pkey;         //id+˽��id������Ψһ����
	
};


typedef struct 
{
	char sKey[41];
}S_CHAR_KEY;

class  CTbl_Char_Key
{
protected:
	
	CMemTable <S_CHAR_KEY> m_table;
	CPkeyCharF<40,1>          m_pkey; 
public:
	CTbl_Char_Key()
	{
		
	}
	virtual ~CTbl_Char_Key()
	{
		
	}
	void Clear()
	{
		m_pkey.Clear();
		m_table.Clear();
	}
	int Insert(char *key)
	{
		if (m_pkey.Find(key))
		{
			return -1;
		}
		S_CHAR_KEY tmp;
		strcpy(tmp.sKey,key);
		
		int rid=m_table.Add(tmp);
		m_pkey.Add(rid,m_table.m_table[rid].sKey);
		return rid;
	}
	char *First()
	{
		int rid;
		if (m_pkey.First(rid))
		{
			return m_table.m_table[rid].sKey;
		}
		return NULL;
	}
	char *Next()
	{
		int rid;
		if (m_pkey.Next(rid))
		{
			return m_table.m_table[rid].sKey;
		}
		return NULL;
	}
};




#endif // !defined(AFX_MDBBASE_H__B2EF1D82_10E5_4C0B_B6EF_A98703B25A7C__INCLUDED_)
