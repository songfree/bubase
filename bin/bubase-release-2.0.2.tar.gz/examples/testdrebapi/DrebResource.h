// DrebResource.h: interface for the CDrebResource class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DREBRESOURCE_H__0C4C71DA_C76E_4D77_9254_C974501DAE0F__INCLUDED_)
#define AFX_DREBRESOURCE_H__0C4C71DA_C76E_4D77_9254_C974501DAE0F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "BF_DrebResource.h"


class CDrebResource : public CBF_DrebResource 
{
public:
	CDrebResource();
	virtual ~CDrebResource();

};

#endif // !defined(AFX_DREBRESOURCE_H__0C4C71DA_C76E_4D77_9254_C974501DAE0F__INCLUDED_)
